# app.py
from flask import Flask, render_template, request
from joblib import load

app = Flask(__name__)

# Load the trained model
model = load('phishing_model.joblib')

def predict_phishing(url):
    # Assume you have a function to preprocess the URL before making predictions
    # This function should be similar to the one used during training
    # You may need to adapt this based on your actual preprocessing steps
    processed_url = preprocess_url(url)

    # Make the prediction
    prediction = model.predict([processed_url])[0]

    return prediction

def preprocess_url(url):
    # Add your preprocessing logic here
    # This might include tokenization, TF-IDF transformation, etc.
    return url

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    url = None

    if request.method == 'POST':
        url = request.form['url']
        prediction = predict_phishing(url)

    return render_template('index.html', prediction=prediction, url=url)

if __name__ == '__main__':
    app.run(debug=True)
