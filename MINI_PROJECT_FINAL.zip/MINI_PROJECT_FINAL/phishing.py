# phishing_classifier.py
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_curve, auc
from sklearn.pipeline import make_pipeline
from joblib import dump
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import itertools

def remove_null_values(data):
    # Remove rows with null values in 'url' or 'label' columns
    data = data.dropna(subset=['url', 'label'])
    return data

def remove_zero_columns(data):
    # Remove columns with all zero values
    data = data.loc[:, (data != 0).any(axis=0)]
    return data

def export_cleaned_dataset(data, filename='cleaned_dataset.csv'):
    # Export the cleaned dataset to a CSV file
    data.to_csv(filename, index=False)

def plot_confusion_matrix(y_true, y_pred, classes, normalize=False, title='Confusion Matrix', cmap=plt.cm.Blues):
    cm = confusion_matrix(y_true, y_pred)
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized Confusion Matrix:")
    else:
        print('Confusion Matrix, without normalization:')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()

    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()

# Load a dataset with phishing and non-phishing URLs
# You can replace this with your own dataset
# The dataset should have a 'url' column and a 'label' column
data = pd.read_csv('dataset_phishing.csv')

# Remove null values
data = remove_null_values(data)

# Remove columns with all zero values
data = remove_zero_columns(data)

# Export the cleaned dataset
export_cleaned_dataset(data, filename='cleaned_dataset.csv')

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data['url'], data['label'], test_size=0.2, random_state=42)

# Create a TF-IDF vectorizer and a Random Forest classifier
model = make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), RandomForestClassifier(n_estimators=100, random_state=42))

# Evaluate the model using cross-validation
y_pred_cv = cross_val_predict(model, data['url'], data['label'], cv=5)
cv_accuracy = accuracy_score(data['label'], y_pred_cv)
print(f'Cross-Validation Accuracy: {cv_accuracy * 100:.2f}%')

# Fit the model on the training set
model.fit(X_train, y_train)

# Make predictions on the testing set
y_pred = model.predict(X_test)

# Calculate and print the accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Test Set Accuracy: {accuracy * 100:.2f}%')

# Confusion Matrix
confusion_mtx = confusion_matrix(y_test, y_pred)
print('Confusion Matrix:\n', confusion_mtx)

# Classification Report
classification_rep = classification_report(y_test, y_pred)
print('Classification Report:\n', classification_rep)

# Plotting Confusion Matrix
plt.figure(figsize=(8, 6))
plot_confusion_matrix(y_test, y_pred, classes=['Legit', 'Phishing'], normalize=True, title='Normalized Confusion Matrix')
plt.show()

# ROC Curve
y_scores = model.predict_proba(X_test)[:, 1]
fpr, tpr, thresholds = roc_curve(y_test, y_scores)
roc_auc = auc(fpr, tpr)

# Plot ROC Curve
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = {:.2f})'.format(roc_auc))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

# Save the model to a file
dump(model, 'phishing_model.joblib')
